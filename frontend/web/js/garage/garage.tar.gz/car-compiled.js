'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var carUrls = {
    1: '/garage/api/add', // my car url
    2: '', // ex car url
    3: '', // wish car url
    4: '' // test drive car url
  };

  DocumentFragment.prototype.toString = function () {
    var element = document.createElement('div');
    element.appendChild(this);

    return element.innerHTML;
  };

  var carType = null;

  var CarController = function () {
    _createClass(CarController, [{
      key: 'attachUpdateClick',
      value: function attachUpdateClick() {
        $('.update-car').on('click', CarFormEvents.updateClick);
      }
    }, {
      key: 'attachAddBtnClick',
      value: function attachAddBtnClick() {
        $('.add-car-btn').on('click', CarFormEvents.addCarBtnClick);
      }
    }, {
      key: 'attachAddClick',
      value: function attachAddClick() {
        $('#add-car-btn').on('click', CarFormEvents.addClick);
      }
    }, {
      key: 'attachUploadBtnClick',
      value: function attachUploadBtnClick() {
        $('#car-images').on('click', CarFormEvents.uploadBtnClick);
      }
    }, {
      key: 'attachUploadBtnChange',
      value: function attachUploadBtnChange() {
        $('#car-images').on('change', CarFormEvents.uploadBtnChange);
      }
    }, {
      key: 'attachCropBtnClick',
      value: function attachCropBtnClick() {
        $('.crop-button').on('click', CarFormEvents.cropBtnClick);
      }
    }, {
      key: 'attachCloseBtnClick',
      value: function attachCloseBtnClick() {
        $('.mfp-close').on('click', CarFormEvents.closeBtnClick);
      }
    }]);

    function CarController() {
      _classCallCheck(this, CarController);

      this.carsBlock = document.getElementById('garage-my-cars');
      this.template = document.getElementById('my-car-tpl');
    }

    _createClass(CarController, [{
      key: 'render',
      value: function render(carFields) {
        console.log(carFields);
        if (this.carsBlock == null) {
          throw Error('Cars block not founded');
        }

        console.log(this.template.content);
        var tplSource = this.template.content.cloneNode(true);

        var template = Handlebars.compile(tplSource.toString());
        var html = template(carFields);

        $(this.carsBlock).append(html);
      }
    }, {
      key: 'update',
      value: function update(carFormData) {
        return new Promise(function (resolve, reject) {
          $.ajax({
            url: '/garage/api/update', // get car type url
            data: carFormData,
            cache: false,
            type: "POST",
            processData: false,

            contentType: false,
            beforeSend: function beforeSend(xhr) {},
            success: function success(response) {
              console.log(response);
              response.status == 'success' ? resolve(JSON.parse(response.car)) : reject('Some error3');
            },
            error: function error() {
              return reject('Some error2');
            }
          });
        });
      }
      /**
       *
       * @param {FormData} carFormData
       * @return {Promise}
       */

    }, {
      key: 'add',
      value: function add(carFormData) {
        return new Promise(function (resolve, reject) {
          $.ajax({
            url: carUrls[carFormData.get('Car[car_type]')], // get car type url
            data: carFormData,
            cache: false,
            type: "POST",
            processData: false,

            contentType: false,
            beforeSend: function beforeSend(xhr) {},
            success: function success(response) {
              console.log(carFormData.get('Car[images][]'));
              console.log(carUrls[carFormData.get('Car[car_type]')]);
              console.log(response);
              response.status == 'success' ? resolve(JSON.parse(response.car)) : reject('Some error3');
            },
            error: function error() {
              return reject('Some error2');
            }
          });
        });
      }
    }, {
      key: 'previewImage',
      value: function previewImage(images) {

        for (var i = 0; i < images.length; i++) {
          $('#cars-preview').append("<div style='position: relative; display: inline-block'><img src=" + images[i].url + " width='180' style='margin-right: 5px; margin-left: 5px' data-index = " + i + " /><a href='#' class='crop-button'><i class='small material-icons'>aspect_ratio</i></a></div>");
        }
        carController.attachCropBtnClick();
      }
    }, {
      key: 'validateImages',
      value: function validateImages(images) {

        var validate;

        for (var i = 0; i < images.length; i++) {
          var regexp = /\/(jpe?g|png|gif)$/ig;
          validate = regexp.test(images[i].type);
          if (validate === false) break;
        }

        return validate;
      }
    }, {
      key: 'alertUnsupportType',
      value: function alertUnsupportType() {
        alert('Unsupported file type');
      }
    }]);

    return CarController;
  }();

  var CarFormEvents = function () {
    var self = this;
    var resp; //response
    var hiddenInputs = $('#hidden-inputs');
    return {
      addCarBtnClick: function addCarBtnClick(e) {
        console.log('Add car btn click');
        // get car type from data attribute
        carType = $(e.target).data('car-type');

        e.defaultPrevented;
      },
      updateClick: function updateClick(e) {
        console.log('Add car');
        var id = $(this).data('car-id');
        CarForm.id = 'addcar-id-' + id;
        var carData = CarForm.data;
        CarForm.id = 'addcar';
        var mainCar = false;

        if (carData.get('Car[main_car]') == 'on') {
          mainCar = true;
          carData.set('Car[main_car]', 1);
        } else {
          mainCar = false;
          carData.set('Car[main_car]', -1);
        }
        carData.append('Car[car_type]', carType);
        var promise = carController.update(carData);

        promise.then(function (carFields) {
          console.log(carFields);
          $('.mfp-close').click();
          location.reload();
        }, function () {
          console.log('Error');
        });
        e.defaultPrevented;
      },
      addClick: function addClick(e) {
        console.log('Add car');
        var carData = CarForm.data;
        var mainCar = false;
        if (carData.get('Car[main_car]') == 'on') {
          mainCar = true;
          carData.set('Car[main_car]', 1);
        }
        carData.append('Car[car_type]', carType);
        var promise = carController.add(carData);

        promise.then(function (carFields) {
          console.log(carFields);
          $('.mfp-close').click();
          carFields['main_car'] = mainCar;
          carController.render(carFields);
        }, function () {
          console.log('Error');
        });
        e.preventDefault();
      },
      uploadBtnChange: function uploadBtnChange(e) {
        console.log('uploadBtnClick');

        carController.attachCloseBtnClick();

        var carImages = document.getElementById('car-images').files;
        console.log(carImages);
        if (carImages.length > 0) {
          // Progress bar
          var progressBar = function progressBar() {
            var elem = document.getElementById("progress-bar");
            var width = 1;
            var id = setInterval(frame, 10);

            function frame() {
              if (width >= 100) {
                clearInterval(id);
              } else {
                width++;
                elem.style.width = width + '%';
              }
            }
          };

          if (!carController.validateImages(carImages)) {
            return function () {
              $('#cars-preview').append("<span style='color: red'>Wrong format. Only JPEG, PNG, GIF.</span>");
            }();
          }

          var formData = new FormData();

          $.each(carImages, function (key, value) {
            formData.append('image[]', value);
          });

          var uploadImage = function uploadImage() {
            $.ajax({
              url: '/api/image-resize/upload-image',
              type: 'POST',
              data: formData,
              dataType: 'json',
              cache: false,
              enctype: 'multipart/form-data',
              processData: false,
              contentType: false,
              success: function success(response) {
                resp = response;
                carController.previewImage(resp);
                for (var i = 0; i < response.length; i++) {
                  hiddenInputs.append("<input id='cropped-image-" + i + "'" + " type='hidden' name='Car[cropped_images][]' value='" + response[i].url + "'>");
                }
                $('#progress-bar').css('width', 0);
              },
              error: function error(response) {

                console.log('Error!');
              }
            });
          };

          progressBar();
          setTimeout(uploadImage, 1100);
        }
      },
      cropBtnClick: function cropBtnClick(e) {

        e.defaultPrevented;
        console.log('cropBtnClick');

        var cropper;

        var croppImage;

        var oldImage = $(this).prev();

        var image = oldImage.clone();

        var imgUrl = image[0].getAttribute('src');
        if (imgUrl.indexOf('?') !== -1) {
          var arr = imgUrl.split('?');
          imgUrl = arr[0];
        }

        var cropModal = $('#crop-modal');

        var index = Number(image[0].dataset.index);
        //Modal window
        cropModal.openModal({
          dismissible: true,
          ready: function ready(modal, trigger) {

            croppImage = $('#crop-modal .modal-content').append(image).children('img').css('max-width', '100%');

            croppImage[0].width = '480';

            cropper = new Cropper(croppImage[0], {
              aspectRatio: 618 / 440

            });
          },
          complete: function complete() {

            var cropperData = cropper.getData();
            var imageData = cropper.getImageData();
            var data = {
              cropperData: cropperData,
              imageData: imageData,
              index: index,
              imgUrl: imgUrl

            };

            croppImage.remove();
            cropper.destroy();

            $.ajax({
              url: '/api/image-resize/crop-image',
              type: 'POST',
              data: { data: data },
              dataType: 'json',
              cache: false,
              success: function success(response) {
                var imgParent = oldImage.parent();
                var timestamp = new Date().getTime();
                oldImage.remove();
                imgParent.prepend("<img src=" + response.url + '?v=' + timestamp + " width=\"180\" style=\"margin-right: 5px; margin-left: 5px\" data-index = " + index + "/>");
                $("#cropped-image-" + index).val(response.url);
              },
              error: function error(response) {

                console.log('Error!');
              }
            });
          }

        });
        cropModal.css("z-index", 9999);
      },

      closeBtnClick: function closeBtnClick(e) {
        document.getElementById('car-images').value = '';
        $('#cars-preview').find('*').remove();
        hiddenInputs.find('*').remove();

        console.log('Close btn click');
      }

    };
  }();

  var CarForm = {
    id: 'addcar',
    get data() {
      return new FormData(document.getElementById(this.id));
    }
  };

  var carController = new CarController();

  // attach garage events

  carController.attachUploadBtnChange();
  carController.attachAddBtnClick();
  carController.attachAddClick();
  carController.attachUpdateClick();
})();

//# sourceMappingURL=car-compiled.js.map